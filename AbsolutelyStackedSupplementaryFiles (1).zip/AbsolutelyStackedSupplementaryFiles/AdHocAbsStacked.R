
for(i in list.files('C:/Users/defgi/Documents/AbsolutelyStacked/R')){
  source(paste0(
    'C:/Users/defgi/Documents/AbsolutelyStacked/R/',i))
}