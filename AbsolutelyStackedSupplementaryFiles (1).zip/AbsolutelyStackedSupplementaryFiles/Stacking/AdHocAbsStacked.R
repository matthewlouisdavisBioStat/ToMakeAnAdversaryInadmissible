
for(i in list.files('Z:/Dissertation/Stacking/R')){
  source(paste0(
    'Z:/Dissertation/Stacking/R/',i))
}